# Onika Burgers — Meme Rhetorical Ecology
How to publish:
1) Open `index.html` in your browser to preview.
2) **Drag-and-drop deploy**:
   - Netlify: go to app.netlify.com → Sites → “Deploy a site” → drag the folder `onika-burgers-site`.
   - Vercel: vercel.com/new → “Import Project” → “Other” → upload folder.
   - GitHub Pages: create a repo and upload contents; enable Pages from the repo settings.
3) To add more screenshots, put them into `img/` and update the `<img src>` paths in `index.html`.

Ethics note: redact handles/faces for private individuals; add access dates in captions.
